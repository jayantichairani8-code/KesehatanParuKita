<?php
session_start();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edukasi Penyakit Paru-Paru</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <!-- NAVBAR -->
    <div class="navbar">
        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>
    </div>

    <div class="container">

        <div class="hero-edukasi">
            <h1>Edukasi Kesehatan Paru-Paru</h1>

            <p>
                Pelajari fungsi paru-paru, penyebab kerusakan, dampak kesehatan,
                dan cara menjaga kesehatan paru-paru agar tetap optimal.
            </p>
        </div>

    </div>

    <div class="edukasi-grid">
        <div class="edukasi-card">
            <div class="edukasi-icon">
                🫁
            </div>

        <h3>Mengenal Paru-Paru</h3>

        <p>
            Paru-paru adalah organ pernapasan yang berfungsi menyerap oksigen
            dari udara dan mengeluarkan karbon dioksida dari tubuh.
        </p>

        <h4>Fungsi Paru-Paru</h4>

            <ul>
                <li>Menyerap oksigen</li>
                <li>Mengeluarkan karbon dioksida</li>
                <li>Membantu proses pernapasan</li>
                <li>Mendukung metabolisme tubuh</li>
            </ul>
        </div>
    </div>

    <div class="edukasi-card">
        <div class="edukasi-icon">
            🚬
        </div>

        <h3>Kebiasaan Merokok</h3>

        <p>
            Rokok mengandung berbagai zat berbahaya yang dapat merusak jaringan
            paru-paru dan meningkatkan risiko penyakit serius.
        </p>

        <h4>Dampak</h4>

        <ul>
            <li>Batuk kronis</li>
            <li>Sesak napas</li>
            <li>Penurunan fungsi paru</li>
            <li>Kanker paru-paru</li>
            <li>PPOK (Penyakit Paru Obstruktif Kronis)</li>
        </ul>
    </div>

    <div class="edukasi-card">
        <div class="edukasi-icon">
            💨
        </div>

        <h3>Penggunaan Vape</h3>

        <p>
            Vape mengandung zat kimia yang dapat mengganggu kesehatan paru-paru
            apabila digunakan dalam jangka panjang.
        </p>

        <h4>Dampak</h4>

        <ul>
            <li>Iritasi saluran pernapasan</li>
            <li>Batuk berkepanjangan</li>
            <li>Gangguan fungsi paru</li>
            <li>Peradangan paru</li>
        </ul>
    </div>

    <div class="edukasi-card">
        <div class="edukasi-icon">
            🏭
        </div>

        <h3>Paparan Debu dan Polusi</h3>

        <p>
            Pekerja di area konstruksi, bengkel, tambang, dan pabrik memiliki
            risiko lebih tinggi mengalami gangguan paru akibat debu.
        </p>

        <h4>Dampak</h4>

        <ul>
            <li>Gangguan pernapasan</li>
            <li>Peradangan paru</li>
            <li>Penyakit paru kronis</li>
            <li>Penurunan kapasitas paru</li>
        </ul>
    </div>

    <div class="edukasi-card">
        <div class="edukasi-icon">
            😷
        </div>

        <h3>Pencegahan Kerusakan Paru-Paru</h3>

        <ul>
            <li>Hindari merokok</li>
            <li>Gunakan masker saat berada di area berdebu</li>
            <li>Rutin berolahraga</li>
            <li>Hindari paparan asap rokok</li>
            <li>Konsumsi makanan bergizi</li>
            <li>Perbanyak minum air putih</li>
        </ul>
    </div>

    <div class="edukasi-card">
        <div class="edukasi-icon">
            🏃
        </div>

        <h3>Cara Menjaga Kesehatan Paru-Paru</h3>

        <ul>
            <li>Olahraga rutin minimal 30 menit</li>
            <li>Istirahat cukup</li>
            <li>Mengonsumsi buah dan sayur</li>
            <li>Menjaga kebersihan lingkungan</li>
            <li>Menghindari polusi berlebihan</li>
            <li>Melakukan pemeriksaan kesehatan berkala</li>
        </ul>
    </div>

    <footer class="footer">
        🫁 Edukasi Kesehatan Paru-Paru untuk Masyarakat
    </footer>

</body>

</html>