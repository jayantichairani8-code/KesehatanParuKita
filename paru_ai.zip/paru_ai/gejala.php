<?php
session_start();

$_SESSION['merokok'] = $_POST['merokok'];
$_SESSION['lama_merokok'] = $_POST['lama_merokok'];
$_SESSION['paparan_asap'] = $_POST['paparan_asap'];
$_SESSION['lingkungan_debu'] = $_POST['lingkungan_debu'];
$_SESSION['alat_pelindung'] = $_POST['alat_pelindung'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Gejala</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">🫁 LungCare AI</div>
    <div class="menu">
        <a href="index.php">Beranda</a>
        <a href="edukasi.php">Edukasi</a>
        <a href="riwayat.php">Riwayat</a>
    </div>
</div>

<div class="container">
    <div class="card form-card">

        <div class="page-icon">🩺</div>

        <h2 class="form-title">Data Gejala</h2>

        <div class="progress">
            <div class="progress-bar progress-75"></div>
        </div>

        <form action="hasil.php" method="POST">

            <!-- BATUK -->
            <div class="form-group">
                <label>Apakah Anda Sering Mengalami Batuk?</label>
                <div class="radio-group">
                    <label class="radio-item">
                        <input type="radio" name="batuk" value="Ya" required> Ya
                    </label>
                    <label class="radio-item">
                        <input type="radio" name="batuk" value="Tidak"> Tidak
                    </label>
                </div>
            </div>

            <!-- SESAK NAPAS -->
            <div class="form-group">
                <label>Apakah Anda Sering Mengalami Sesak Napas?</label>
                <div class="radio-group">
                    <label class="radio-item">
                        <input type="radio" name="sesak" value="Ya" required> Ya
                    </label>
                    <label class="radio-item">
                        <input type="radio" name="sesak" value="Tidak"> Tidak
                    </label>
                </div>
            </div>

            <!-- NYERI DADA -->
            <div class="form-group">
                <label>Apakah Anda Sering Mengalami Nyeri Dada?</label>
                <div class="radio-group">
                    <label class="radio-item">
                        <input type="radio" name="nyeri_dada" value="Ya" required> Ya
                    </label>
                    <label class="radio-item">
                        <input type="radio" name="nyeri_dada" value="Tidak"> Tidak
                    </label>
                </div>
            </div>

            <!-- MUDAH LELAH -->
            <div class="form-group">
                <label>Apakah Anda Mudah Lelah Saat Beraktivitas?</label>
                <div class="radio-group">
                    <label class="radio-item">
                        <input type="radio" name="mudah_lelah" value="Ya" required> Ya
                    </label>
                    <label class="radio-item">
                        <input type="radio" name="mudah_lelah" value="Tidak"> Tidak
                    </label>
                </div>
            </div>

            <center>
                <button type="submit" class="btn">
                    ANALISIS SEKARANG 🔍
                </button>
            </center>

        </form>

    </div>
</div>

<div class="footer">
    Langkah 3 dari 4
</div>

</body>
</html>