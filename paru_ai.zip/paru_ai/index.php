<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Deteksi Risiko Paru-Paru</title>

    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar">

        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>

    </nav>

    <!-- HERO SECTION -->
    <div class="container">

        <section class="hero">

            <!-- TEXT -->
            <div class="hero-text">

                <div class="hero-badge">
                    ✨ Sistem Kecerdasan Buatan
                </div>

                <h1>
                    Sistem Deteksi Risiko Kerusakan Paru-Paru Berdasarkan Gaya Hidup
                </h1>

                <p>
                    Website ini membantu masyarakat mengetahui tingkat risiko
                    kerusakan paru-paru berdasarkan gaya hidup dan gejala yang
                    dialami menggunakan metode Decision Tree.
                </p>

                <div class="hero-buttons">

                    <a href="data_pengguna.php">
                        <button class="btn">
                            MULAI PEMERIKSAAN
                        </button>
                    </a>

                    <a href="edukasi.php" class="btn-secondary">
                        Pelajari Paru-Paru
                    </a>

                </div>

            </div>

            <!-- GAMBAR -->
            <div class="hero-image">

                <img
                    src="assets/images/paru.png"
                    alt="Ilustrasi Paru-Paru">

            </div>

        </section>

    </div>

    <!-- FITUR -->
    <div class="container">

        <h2 align="center">
            Mengapa Menggunakan Sistem Ini?
        </h2>

        <br>

        <div class="features">

            <div class="feature-card">

                <h3>🩺 Analisis Risiko</h3>

                <p>
                    Menilai tingkat risiko kerusakan paru-paru berdasarkan
                    gaya hidup dan gejala yang dialami pengguna.
                </p>

            </div>

            <div class="feature-card">

                <h3>🌳 Decision Tree</h3>

                <p>
                    Menggunakan metode Decision Tree untuk menghasilkan
                    klasifikasi risiko rendah, sedang, dan tinggi.
                </p>

            </div>

            <div class="feature-card">

                <h3>📚 Edukasi Kesehatan</h3>

                <p>
                    Menyediakan informasi mengenai kesehatan paru-paru,
                    faktor risiko, serta langkah pencegahan.
                </p>

            </div>

        </div>

    </div>

    <!-- FOOTER -->
    <footer class="footer">
        © 2026 Sistem Deteksi Risiko Kerusakan Paru-Paru
    </footer>

</body>

</html>