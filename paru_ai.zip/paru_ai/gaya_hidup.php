<?php
session_start();

if(!isset($_SESSION['id_pengguna'])){

header("Location:data_pengguna.php");

exit;

}

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gaya Hidup</title>

    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <!-- NAVBAR -->
    <div class="navbar">
        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>
    </div>

    <div class="container">

        <div class="card form-card">

            <div class="page-icon">
                🚬
            </div>

            <h2 class="form-title">
                Data Gaya Hidup
            </h2>

            <div class="progress">
                <div class="progress-bar progress-50"></div>
            </div>

            <form action="gejala.php" method="POST">

                <!-- MEROKOK -->
                <div class="form-group">
                    <label>Apakah Anda Merokok?</label>

                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" name="merokok" value="Ya" required>
                            Ya
                        </label>

                        <label class="radio-item">
                            <input type="radio" name="merokok" value="Tidak">
                            Tidak
                        </label>
                    </div>
                </div>

                <!-- LAMA MEROKOK -->
                <div class="form-group">
                    <label>Berapa Lama Anda Merokok?</label>

                    <select name="lama_merokok" required>
                        <option value="">-- Pilih --</option>
                        <option value="Tidak Pernah">Tidak Pernah</option>
                        <option value="Kurang dari 1 tahun">Kurang dari 1 Tahun</option>
                        <option value="1-5 tahun">1 - 5 Tahun</option>
                        <option value="Lebih dari 5 tahun">Lebih dari 5 Tahun</option>
                    </select>
                </div>

                <!-- PAPARAN ASAP -->
                <div class="form-group">
                    <label>Apakah Anda Sering Terpapar Asap Rokok?</label>

                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" name="paparan_asap" value="Ya" required>
                            Ya
                        </label>

                        <label class="radio-item">
                            <input type="radio" name="paparan_asap" value="Tidak">
                            Tidak
                        </label>
                    </div>
                </div>

                <!-- DEBU / POLUSI -->
                <div class="form-group">
                    <label>
                        Apakah Lingkungan Anda Berhubungan Dengan Debu, Asap, atau Bahan Kimia?
                    </label>

                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" name="lingkungan_debu" value="Ya" required>
                            Ya
                        </label>

                        <label class="radio-item">
                            <input type="radio" name="lingkungan_debu" value="Tidak">
                            Tidak
                        </label>
                    </div>
                </div>

                <!-- APD -->
                <div class="form-group">
                    <label>
                        Apakah Anda Menggunakan Alat Pelindung Saat Berada di Lingkungan Berdebu?
                    </label>

                    <select name="alat_pelindung" required>
                        <option value="">-- Pilih --</option>
                        <option value="Selalu">Selalu</option>
                        <option value="Kadang-kadang">Kadang-kadang</option>
                        <option value="Tidak Pernah">Tidak Pernah</option>
                    </select>
                </div>

                <center>
                    <button type="submit" class="btn">
                        Lanjut ke Gejala →
                    </button>
                </center>

            </form>

        </div>

    </div>

    <div class="footer">
        Langkah 2 dari 4
    </div>

</body>

</html>