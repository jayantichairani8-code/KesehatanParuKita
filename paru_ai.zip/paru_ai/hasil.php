<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['nama'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: gejala.php");
    exit;
}

$_SESSION['batuk'] = $_POST['batuk'] ?? '';
$_SESSION['sesak'] = $_POST['sesak'] ?? '';
$_SESSION['nyeri_dada'] = $_POST['nyeri_dada'] ?? '';
$_SESSION['mudah_lelah'] = $_POST['mudah_lelah'] ?? '';

$nama            = $_SESSION['nama'];
$umur            = $_SESSION['umur'];
$jenis_kelamin   = $_SESSION['jenis_kelamin'];
$pekerjaan       = $_SESSION['pekerjaan'];

$merokok         = $_SESSION['merokok'];
$lama            = $_SESSION['lama_merokok'];
$paparan         = $_SESSION['paparan_asap'];
$debu            = $_SESSION['lingkungan_debu'];
$apd             = $_SESSION['alat_pelindung'];

$batuk           = $_SESSION['batuk'];
$sesak           = $_SESSION['sesak'];
$nyeri           = $_SESSION['nyeri_dada'];
$lelah           = $_SESSION['mudah_lelah'];

$skor = 0;
$faktor = [];

/* MEROKOK */

if ($merokok == "Ya") {
    $skor += 2;
    $faktor[] = "Merokok";
}

/* LAMA MEROKOK */

if ($lama == "Kurang dari 1 tahun") {
    $skor += 1;
    $faktor[] = "Merokok kurang dari 1 tahun";
}

if ($lama == "1-5 tahun") {
    $skor += 2;
    $faktor[] = "Merokok 1-5 tahun";
}

if ($lama == "Lebih dari 5 tahun") {
    $skor += 3;
    $faktor[] = "Merokok lebih dari 5 tahun";
}

/* PAPARAN ASAP */

if ($paparan == "Ya") {
    $skor += 1;
    $faktor[] = "Terpapar asap rokok";
}

/* DEBU */

if ($debu == "Ya") {
    $skor += 1;
    $faktor[] = "Lingkungan berdebu/polusi";
}

/* APD */

if ($apd == "Kadang-kadang") {
    $skor += 1;
    $faktor[] = "Jarang menggunakan APD";
}

if ($apd == "Tidak Pernah") {
    $skor += 2;
    $faktor[] = "Tidak menggunakan APD";
}

/* GEJALA */

if ($batuk == "Ya") {
    $skor += 1;
    $faktor[] = "Sering batuk";
}

if ($sesak == "Ya") {
    $skor += 2;
    $faktor[] = "Sesak napas";
}

if ($nyeri == "Ya") {
    $skor += 2;
    $faktor[] = "Nyeri dada";
}

if ($lelah == "Ya") {
    $skor += 1;
    $faktor[] = "Mudah lelah";
}

if ($skor >= 8) {
    $risiko = "TINGGI";
} elseif ($skor >= 4) {
    $risiko = "SEDANG";
} else {
    $risiko = "RENDAH";
}

$id_pengguna =
$_SESSION['id_pengguna'];

mysqli_query(
    $conn,
    "INSERT INTO pemeriksaan (
        id_pengguna,
        merokok,
        lama_merokok,
        paparan_asap,
        lingkungan_debu,
        alat_pelindung,
        batuk,
        sesak,
        nyeri_dada,
        mudah_lelah,
        skor,
        risiko
    ) VALUES (
        '$id_pengguna',
        '$merokok',
        '$lama',
        '$paparan',
        '$debu',
        '$apd',
        '$batuk',
        '$sesak',
        '$nyeri',
        '$lelah',
        '$skor',
        '$risiko'
    )"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Hasil Analisis</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <div class="navbar">
        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>
    </div>

    <div class="container">
        <div class="card">

            <h2 align="center">
                📊 Hasil Analisis Risiko
            </h2>

            <div class="progress">
                <div class="progress-bar progress-100"></div>
            </div>

            <center>
                <?php
                if ($risiko == "TINGGI") {
                    echo "<div class='badge-risiko high'>RISIKO TINGGI</div>";
                } elseif ($risiko == "SEDANG") {
                    echo "<div class='badge-risiko medium'>RISIKO SEDANG</div>";
                } else {
                    echo "<div class='badge-risiko low'>RISIKO RENDAH</div>";
                }
                ?>
            </center>

            <br>

            <p>
                <b>Nama:</b> <?php echo $nama; ?>
            </p>

            <p>
                <b>Skor Risiko:</b> <?php echo $skor; ?>
            </p>

        </div>
    </div>

    <div class="card">
        <h2>Faktor Yang Mempengaruhi</h2>

            <ul class="list-hasil">
            <?php foreach ($faktor as $item): ?>
                <li>✓ <?= $item; ?></li>
                <?php endforeach; ?>
            </ul>
    </div>

    <div class="card">
        <h2>Kemungkinan Kondisi Paru-Paru</h2>

            <ul class="list-hasil">
            <?php if ($risiko == "TINGGI") : ?>
                <li>Risiko gangguan paru kronis</li>
                <li>Risiko penurunan fungsi paru</li>
                <li>Risiko penyakit paru obstruktif</li>

            <?php elseif ($risiko == "SEDANG") : ?>
                <li>Risiko iritasi saluran pernapasan</li>
                <li>Potensi penurunan fungsi paru ringan</li>

            <?php else : ?>
                <li>Kondisi paru relatif baik</li>
                <li>Tetap perlu menjaga kesehatan paru</li>
            <?php endif; ?>
            </ul>
    </div>

    <div class="card">
        <h2>Saran dan Edukasi</h2>

            <ul class="list-hasil">
            <?php
                if ($risiko == "TINGGI") {
            ?>
                    <li>Segera periksa ke dokter paru.</li>
                    <li>Hentikan kebiasaan merokok.</li>
                    <li>Hindari paparan asap rokok.</li>
                    <li>Gunakan masker saat berada di area berpolusi.</li>
                    <li>Lakukan olahraga ringan secara rutin.</li>

            <?php
                } elseif ($risiko == "SEDANG") {
            ?>
                    <li>Kurangi faktor risiko yang dapat memperburuk kondisi paru.</li>
                    <li>Tingkatkan aktivitas fisik secara bertahap.</li>
                    <li>Hindari lingkungan yang berpolusi dan berasap.</li>

            <?php
                } else {
            ?>
                    <li>Pertahankan pola hidup sehat.</li>
                    <li>Tetap lakukan olahraga secara rutin.</li>
                    <li>Hindari asap rokok dan polusi udara.</li>

            <?php
                }
            ?>
            </ul>
    </div>

    <div class="card">
        <h2>⚠ Disclaimer</h2>
        <p>
        Hasil yang diberikan merupakan prediksi berdasarkan data kuesioner dan
        bukan diagnosis medis. Untuk pemeriksaan lebih lanjut, silakan
        berkonsultasi dengan tenaga kesehatan di rumah sakit terdekat.
        </p>
    </div>

    <div class="footer">Pemeriksaan Selesai ✔</div>

</body>
</html>