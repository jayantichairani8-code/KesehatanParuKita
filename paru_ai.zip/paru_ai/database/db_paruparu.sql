CREATE DATABASE IF NOT EXISTS db_paruparu;
USE db_paruparu;

CREATE TABLE pengguna (
id INT AUTO_INCREMENT PRIMARY KEY,
nama VARCHAR(100) NOT NULL,
umur INT NOT NULL,
jenis_kelamin VARCHAR(20) NOT NULL,
pekerjaan VARCHAR(100) NOT NULL,
tanggal DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE pemeriksaan (
id INT AUTO_INCREMENT PRIMARY KEY,
id_pengguna INT,
merokok VARCHAR(20),
lama_merokok VARCHAR(50),
paparan_asap VARCHAR(20),
lingkungan_debu VARCHAR(20),
alat_pelindung VARCHAR(50),
batuk VARCHAR(20),
sesak VARCHAR(20),
nyeri_dada VARCHAR(20),
mudah_lelah VARCHAR(20),
skor INT,
risiko VARCHAR(20),

tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY (id_pengguna)
REFERENCES pengguna(id)
ON DELETE CASCADE
);