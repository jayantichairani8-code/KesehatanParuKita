<?php
session_start();

include 'koneksi.php';

$query = mysqli_query($conn,
    "SELECT
        pemeriksaan.*,
        pengguna.nama
    FROM pemeriksaan
    INNER JOIN pengguna
    ON pemeriksaan.id_pengguna = pengguna.id
    ORDER BY pemeriksaan.id DESC"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pemeriksaan</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR -->
    <div class="navbar">
        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>
    </div>

    <div class="container">
        <div class="card">

            <h2 align="center">
                📋 Riwayat Pemeriksaan
            </h2>

            <br>

            <input
                type="text"
                id="searchInput"
                class="search-box"
                placeholder="Cari nama pengguna..."
            >

            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Risiko</th>
                        <th>Detail</th>
                    </tr>
                </thead>

                <tbody id="tableBody">

                    <?php

                    $no = 1;

                    while ($data = mysqli_fetch_assoc($query)) {

                    ?>

                    <tr>
                        <td>
                            <?php echo $no++; ?>
                        </td>

                        <td>
                            <?php echo $data['nama']; ?>
                        </td>

                        <td>
                            <?php
                            if($data['risiko']=="TINGGI"){

                                echo "<span class='status-tinggi'>TINGGI</span>";
                            }
                            elseif($data['risiko']=="SEDANG"){

                                echo "<span class='status-sedang'>SEDANG</span>";
                            }
                            else{
                                echo "<span class='status-rendah'>RENDAH</span>";
                            }
                            ?>
                        </td>

                        <td>
                            <a href="detail.php?id=<?php echo $data['id']; ?>">
                                <button class="btn">
                                    Lihat
                                </button>
                            </a>
                        </td>
                    </tr>

                    <?php

                    }

                    ?>

                </tbody>

                </table>
                    </div>
                    </div>

                    <div class="footer">
                        Data Riwayat Pemeriksaan
                    </div>

                    <script>
                        const searchInput = document.getElementById("searchInput");

                        searchInput.addEventListener("keyup", function () {
                            let filter = this.value.toLowerCase();

                            let rows = document.querySelectorAll("#tableBody tr");

                            rows.forEach(function (row) {
                                let nama = row.cells[1].innerText.toLowerCase();

                                if (nama.includes(filter)) {
                                    row.style.display = "";
                                } else {
                                    row.style.display = "none";
                                }
                            });
                        });
                    </script>

</body>
</html>