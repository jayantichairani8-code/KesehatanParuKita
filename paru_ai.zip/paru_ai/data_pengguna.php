<?php
session_start();

include 'koneksi.php';

if(isset($_POST['simpan_pengguna'])){

$nama = $_POST['nama'];
$umur = $_POST['umur'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$pekerjaan = $_POST['pekerjaan'];

mysqli_query($conn,

"INSERT INTO pengguna
(
nama,
umur,
jenis_kelamin,
pekerjaan
)

VALUES
(
'$nama',
'$umur',
'$jenis_kelamin',
'$pekerjaan'
)"
);

$id_pengguna = mysqli_insert_id($conn);

$_SESSION['id_pengguna'] = $id_pengguna;

$_SESSION['nama'] = $nama;
$_SESSION['umur'] = $umur;
$_SESSION['jenis_kelamin'] = $jenis_kelamin;
$_SESSION['pekerjaan'] = $pekerjaan;

header("Location:gaya_hidup.php");

exit;

}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengguna</title>

    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            🫁 LungCare AI
        </div>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="edukasi.php">Edukasi</a>
            <a href="riwayat.php">Riwayat</a>
        </div>
    </div>

    <!-- Form Data Pengguna -->
    <div class="container">
        <div class="card form-card">

            <div class="page-icon">
                👤
            </div>

            <h2 class="form-title">Data Pengguna</h2>

            <div class="progress">
                <div class="progress-bar"></div>
            </div>

            <form method="POST">

                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama" required>
                </div>

                <div class="form-group">
                    <label>Umur</label>
                    <input type="number" name="umur" min="1" max="120" required>
                </div>

                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" required>
                        <option value="">-- Pilih --</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Pekerjaan</label>
                    <input type="text" name="pekerjaan" required>
                </div>

                <center>
                    <button type="submit" name="simpan_pengguna" class="btn">
                        Lanjut ke Gaya Hidup →
                    </button>
                </center>

            </form>

        </div>
    </div>

    <div class="footer">
        Langkah 1 dari 4
    </div>

</body>

</html>