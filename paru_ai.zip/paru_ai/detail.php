<?php

include 'koneksi.php';

    $id = $_GET['id'];
    $query = mysqli_query($conn,
        "SELECT
            pemeriksaan.*,
            pengguna.nama,
            pengguna.umur,
            pengguna.jenis_kelamin,
            pengguna.pekerjaan
        FROM pemeriksaan
        INNER JOIN pengguna
        ON pemeriksaan.id_pengguna =
            pengguna.id
        WHERE pemeriksaan.id='$id'"
    );

    $data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pemeriksaan</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="container">
        <div class="card">

            <h2>📋 Detail Pemeriksaan</h2>
            <hr>
            <br>

            <p>
                <b>Nama :</b>
                <?php echo $data['nama']; ?>
            </p>

            <p>
                <b>Umur :</b>
                <?php echo $data['umur']; ?>
            </p>

            <p>
                <b>Jenis Kelamin :</b>
                <?php echo $data['jenis_kelamin']; ?>
            </p>

            <p>
                <b>Pekerjaan :</b>
                <?php echo $data['pekerjaan']; ?>
            </p>

            <br>

            <h3>Data Gaya Hidup</h3>

            <p>
                <b>Merokok :</b>
                <?php echo $data['merokok']; ?>
            </p>

            <p>
                <b>Lama Merokok :</b>
                <?php echo $data['lama_merokok']; ?>
            </p>

            <p>
                <b>Paparan Asap :</b>
                <?php echo $data['paparan_asap']; ?>
            </p>

            <p>
                <b>Lingkungan Debu :</b>
                <?php echo $data['lingkungan_debu']; ?>
            </p>

            <p>
                <b>Alat Pelindung :</b>
                <?php echo $data['alat_pelindung']; ?>
            </p>

            <br>

            <h3>Data Gejala</h3>

            <p>
                <b>Batuk :</b>
                <?php echo $data['batuk']; ?>
            </p>

            <p>
                <b>Sesak :</b>
                <?php echo $data['sesak']; ?>
            </p>

            <p>
                <b>Nyeri Dada :</b>
                <?php echo $data['nyeri_dada']; ?>
            </p>

            <p>
                <b>Mudah Lelah :</b>
                <?php echo $data['mudah_lelah']; ?>
            </p>

            <br>

            <h3>Hasil Analisis</h3>

            <p>
                <b>Skor :</b>
                <?php echo $data['skor']; ?>
            </p>

            <p>
                <b>Risiko :</b>
                <?php echo $data['risiko']; ?>
            </p>

            <br>

            <a href="riwayat.php">
                <button class="btn">
                    ← Kembali
                </button>
            </a>

        </div>
    </div>

</body>

</html>